import java.io.*;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;

public class UploadTCPServer {
    public static void main(String[] args) throws IOException {
		// ============= 1. 创建服务器端对象 ================
        
        // ================================================
        
        // ============= 2. 绑定地址并启动服务端 ==============
        
        // =================================================
        
        while (true){
        
			// ============= 3. 调用accept( )方法持续接收客户端请求 ==============
            
            // ===============================================================
            
            
            new Thread(new Runnable() {
                @Override
                public void run() {
                
					
                    try {
                    
						// ============= 4. 针对每一个客户端请求创建一个线程进行管理 ==============
                        
                        // =================================================================
                        
                    }catch (Exception ex){
                        ex.printStackTrace();
                    }finally {
                        try {
							// ============= 5. 程序结束时确保socket关闭 ================
                            
                            // ========================================================
                            
                        } catch (IOException e) {
                            throw new RuntimeException(e);
                        }
                    }
                    
                }
            }).start();
        }
    }

    public static void clientConnectionThread(Socket socket) throws IOException {
        // 获取发送流
        DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
        // 获取接收流
        DataInputStream dis = new DataInputStream(socket.getInputStream());

		// ============= 6. 创建缓冲区并读取文件数据 ==============
        
		// =====================================================
        
        // 保存上传的文件
        // ============= 7. 创建目标目录 ==============
        
        // ==========================================
        
        if(!dir.exists()){
            dir.mkdirs();
        }
        
        // ============= 8. 访问目标文件 ==============
        
		// =============================================
        
        // ============= 9. 返回 "上传成功" 信息 ==============
        
        // ==================================================
        
        dos.flush();
    }
}
