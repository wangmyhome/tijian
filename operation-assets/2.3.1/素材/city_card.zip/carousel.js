
var i = 0;           // 当前显示的广告图索引
var timer = null;    // 定时器
const delay = 1000;    // 广告图自动切换的间隔时间
const width = 958;     // 每张图片的宽度
const speed = 400;     // 动画时间

//开启定时器
function startTimer() {
  if (timer == null) {
    // 设置自动定时切换
    timer = setInterval(carouselPlay, delay);
  }
}

//停止定时器
function stopTimer() {
  if (timer != null) {
    clearInterval(timer);
    timer = null;
  }
}

//轮播切换函数
function carouselPlay() {
  ++i;
  imgChange();//广告图片切换
  dotChange();//圆点样式切换
}

// 请在规定的区域内作答，超出规定区域作答无效。请勿更改规定区域以外的任何代码，否则可能会无法得分。 

//切换广告图片
function imgChange() {

  // ==== 1. 实现广告图片切换 =====


  // ==== END ====




  // ==== 2. 添加切换动画 =====


  // ==== END ====

}

// 切换对应的圆点
function dotChange() {

  // ==== 3. 实现切换到对应的圆点样式 ====


  // ==== END ====
}



$(function () {
  //设置ul的长度，主要目的就是让5张广告图在一行显示
  $('.hot').width($('.hot li').length * width);
  startTimer();//启动定时器


  // ==== 4. 实现鼠标移入，暂停自动播放，并且显示左右箭头 ====


  // ==== END ====




  // ==== 5. 实现鼠标移出，开始自动播放,并且隐藏左右箭头 ====


  // ==== END ====




  // ==== 6. 实现鼠标移入小圆点处，动画切换至对应图片位置且圆点样式同步更新 ====


  // ==== END ====



  //左箭头按钮功能
  $('.prev').click(function () {

    // ==== 7. 实现鼠标单击左箭头，切换至上一张图片 ====


    // ==== END ====

  });

  //右箭头按钮功能
  $('.next').click(function () {

    // ==== 8. 实现鼠标单击右箭头，切换至下一张图片 ====


    // ==== END ====

  });

});




