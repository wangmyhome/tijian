import java.io.*;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;

public class ServerTest {
    public static void main(String[] args) throws IOException {
    
		// ============= 1. 创建服务器端ServerSocket对象 ==============
        
        // =================================================
        
        // ============= 2. 将ServerSocket对象绑定5678端口号 ==============
        
        // =================================================
        
        System.out.println("服务器启动。。。");
        while (true){
        
			// ============= 3. 调用accept( )方法持续接收客户端请求 ==============
            
            // =================================================
            
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                    
						// ============= 4. 在单独的线程中处理socket ==============
                        c
                        // =================================================
                        
                    }catch (Exception ex){
                        ex.printStackTrace();
                    }finally {
                        try {
							
							// ============= 5. 确保socket关闭 ==============
                            
                            // =================================================
                            
                        } catch (IOException e) {
                            throw new RuntimeException(e);
                        }
                    }
                }
            }).start();
        }
    }

    public static void clientConnectionThread(Socket socket) throws IOException {
        // 获取发送流
        DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
        
        // ============= 6. 通过Socket对象的getInputStream方法获取客户端的数据流 ==============
        
        // =================================================

        
        int fileLen = dis.readInt();
        byte[] fileData = new byte[fileLen];
        
        // ============= 7. 读取文件数据 ==============
        
        // =================================================
        
        // ============= 8. 保存上传的文件 ==============
        
        // =================================================
        
        if(!dir.exists()){
            dir.mkdirs();
        }
        
        // ============= 9. 创建要保存的文件 ==============
        
        // =================================================
        
        try{
			// ============= 10. 将数据流写入到文件中并释放 ==============
            
            // =================================================
        }finally {
			// ============= 11. 关闭数据流 ==============
            
            // =================================================
        }


        System.out.println("数据接收完毕");
    }
}
